
diary C:\matlab_results\results.txt
diary on

activate = 0;
activate_sensor = 0;
wd = 0;
wp =0;
wc = 0;
for i=1:4000
    
    if(f(i)> 0)
        activate = activate + 1;
        if(w(i)>= 80 && w(i)<=435 )
            wp = wp + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector activated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was partially submerged, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        elseif(w(i)>435 && w(i)<=533)
            wc = wc + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector activated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was completely submerged, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        else
            wd = wd + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector activated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was dry, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        end
        
    else
        if(w(i)> 80 && w(i)<435 )
            wp = wp + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector deactivated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was partially submerged, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        elseif(w(i)>435 && w(i)<=533)
            wc = wc + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector deactivated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was completely submerged, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        else
            wd = wd + 1;
            fprintf("\nDevice No. " + sensorId(i) + " smoke detector activated!" + " GPS location is: "+ long(i) + "," + lat(i) + "\n"+ " water sensor was dry, with temp: " + t(i) + " degrees and " + h(i) + " humidity percentage \n\n" )
        end
    end
end

for k=1:100
    activate_sensor = 0;
        wd_activate = 0;
        wp_activate =0;
        wc_activate = 0;
    for i=1:4000        
        if(sensorId(i) == k)
            if(f(i)> 0)
            activate_sensor = activate_sensor + 1;
            end
         if(w(i)>= 80 && w(i)<=435 )
            wp_activate = wp_activate + 1;
         elseif(w(i)>435 && w(i)<=533)
            wc_activate = wc_activate + 1;
        else
            wd_activate = wd_activate + 1;
         end 
        end
    end

    fprintf("Device No. " + k + " the smoke detector has been activated " + activate_sensor + " times. \n")
    fprintf("the water sensor was dry " + wd_activate + " times\n")
    fprintf("the water sensor was partially submerged " + wp_activate + " times\n")
    fprintf("the water sensor was completely submerged " + wc_activate + " times \n\n")
end
 fprintf("Smoke detectors activated " + activate + " times \n")
 fprintf("Water sensor was dry " + wd + " times \n")
 fprintf("Water sensor was partially submerged " + wp + " times \n")
 fprintf("Water sensor was completely submerged " + wc + " times \n")
diary off