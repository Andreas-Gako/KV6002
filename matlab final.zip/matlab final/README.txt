In order for the diary to work a folder called matlab_results needs to be created on the C:
drive

C:\matlab_results
