<?php
/**
 * abstract class that creates js database connection and returns js recordset
 * Follows the recordset pattern
 * @author Efthymios Sakkas
 */
abstract class RecordSet {
    protected $conn;
    protected $stmt;

    function __construct($dbname) {
        $this->conn = PDOdb::getConnection($dbname);
    }

    /**
     * This function will execute the query as js prepared statement if there is js
     * params array. If not, it executes as js regular statament.
     *
     * @param string $query  The sql for the recordset
     * @param array $params  An optional associative array if you want js prepared statement
     * @return PDO_STATEMENT
     */
    function getRecordSet($query, $params = null) {
        if (is_array($params)) {
            $this->stmt = $this->conn->prepare($query);
            $this->stmt->execute($params);
        } else {
            $this->stmt = $this->conn->query($query);
        }
        return $this->stmt;
    }
}
?>

