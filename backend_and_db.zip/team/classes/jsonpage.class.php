<?php

/**
 * Creates js JSON page based on the parameters
 *
 * @author Efthymios Sakkas
 *
 */
class JSONpage
{
    private $page;
    private $recordset;


    /**
     * @param $pathArr - an array containing the route information
     */
    public function __construct($pathArr, $recordset)
    {
        $this->recordset = $recordset;
        $path = (empty($pathArr[1])) ? "api" : $pathArr[1];

        switch ($path) {
            case 'api':
                $this->page = $this->json_welcome();
                break;
            case 'owner':
                $this->page = $this->json_owner();
                break;
            case 'fire';
                $this->page = $this->json_fire();
                break;
            case 'login':
                $this->page = $this->json_login();
                break;
            case 'update':
                $this->page = $this->json_update();
                break;
            default:
                $this->page = $this->json_error();
                break;

        }
    }

//an arbitrary max length of 20 is set
    private function sanitiseString($x)
    {
        return substr(trim(filter_var($x, FILTER_SANITIZE_STRING)), 0, 20);
    }

    /**
     * @returns A message that welcomes the users and shows the APIs available
     */
    private function json_welcome()
    {
        $msg = array("Message" => "Welcome", "Author" => "Efthymios Sakkas", "APIs" => "Owner,Fire,Login,Update");
        return json_encode($msg);
    }
    /**
     * @returns A message when an error occurs
     */
    private function json_error()
    {
        $msg = array("message" => "error");
        return json_encode($msg);
    }

    /**
     * json_owner function that returns all the metrics that the home owner needs.
     *
     */
    private function json_owner()
    {
        $input = json_decode(file_get_contents("php://input"));

        if (!isset($input->token)) {
            return json_encode(array("status" => 400, "message" => "Invalid request"));
        }

        try {
            $tokenDecoded = \firebase\jwt\jwt::decode($input->token, 'JWTKEY', array('HS256'));
        }
        catch (UnexpectedValueException $e) {
            return json_encode(array("status" => 401, "message" => $e->getMessage()));
        }

        if ($tokenDecoded->type=="1"){
            return json_encode(array("status" => 401, "message" => "Not authorised"));
        }

        $query = "SELECT sensors.sensorId, userDevice.nickname, sensors.temperature, sensors.humidity, sensors.fire, sensors.water, sensors.gpsx, sensors.gpsy, userDevice.deviceId, sensors.date
                  FROM sensors JOIN users JOIN userDevice
                  WHERE users.userId = userDevice.userId AND userDevice.deviceId = sensors.sensorId AND users.userId = :userId
                  ORDER BY sensors.date";
        $userId = $tokenDecoded -> userId;
        $params = [ "userId"=> $userId];
        return ($this->recordset->getJSONRecordSet($query, $params));

    }

    /**
     * json_fire function returns the metrics that the fire department needs.
     *
     */
    private function json_fire()
    {
        $input = json_decode(file_get_contents("php://input"));

        if (!isset($input->token)) {
        return json_encode(array("status" => 400, "message" => "Invalid request"));
    }

        try {
            $jwtkey = "JWTKEY";
            $tokenDecoded = \firebase\jwt\jwt::decode($input->token, $jwtkey, array('HS256'));
        }
        catch (UnexpectedValueException $e) {
            return json_encode(array("status" => 401, "message" => $e->getMessage()));
        }

        if ($tokenDecoded->type=="2"){
            return json_encode(array("status" => 401, "message" => "Not authorised"));
        }

        $query = "SELECT sensors.temperature, sensors.fire, sensors.water, sensors.gpsx, sensors.gpsy, users.type, sensors.date, sensors.sensorId 
               From userDevice join sensors on deviceId = sensorId
               join users on userDevice.userId = users.userId 
               WHERE sensors.fire = 'TRUE'
               ORDER BY sensors.fire DESC,sensors.date";
        $params = [];
        return ($this->recordset->getJSONRecordSet($query, $params));
    }

    /**
     * json_login checks login data to let the user use all the functions of the website.
     *
     */
    private function json_login() {
        $msg = "Invalid request. Username and password required";
        $status = 400;
        $token = null;
        $input = json_decode(file_get_contents("php://input"));

        if ($input) {
            if (isset($input->email) && isset($input->password)) {
                $query  = "SELECT name, surname, email, password, type, userId FROM users WHERE email LIKE :email";
                $params = ["email" => $input->email];
                $res = json_decode($this->recordset->getJSONRecordSet($query, $params),true);
                $password = ($res['count']) ? $res['data'][0]['password'] : null;

                if ($input->password) {
                    $msg = "User authorised. Welcome ". $res['data'][0]['name'] ;
                    console.log("1");
                    $status = 200;
                    $token = array();
                    $token['email'] = $input->email;
                    $token['name'] = $res['data'][0]['name'];
                    $token['userId'] = $res['data'][0]['userId'];
                    $token['type'] = $res['data'][0]['type'];
                    $jwtkey = "JWTKEY";
                    $token['iat'] = time();
                    $token['exp'] = time() + (60*60*60);
                    $token = \firebase\jwt\jwt::encode($token, $jwtkey);

                } else {
                    $msg = "email or password are invalid";
                    $status = 401;
                    $token = null;
                }
            }
        }

        return json_encode(array("status" => $status, "message" => $msg, "token" => $token));
    }
    /**
     * json_update updates the nickname of a device
     *
     */
    private function json_update() {
        $input = json_decode(file_get_contents("php://input"));


        if (!isset($input->token)) {
            return json_encode(array("status" => 400, "message" => "Invalid request"));
        }

        try {
            $tokenDecoded = \firebase\jwt\jwt::decode($input->token, 'JWTKEY', array('HS256'));
        }
        catch (UnexpectedValueException $e) {
            return json_encode(array("status" => 401, "message" => $e->getMessage()));
        }

        $query  = "UPDATE userDevice SET nickname = :nickname WHERE userDevice.deviceId = :deviceId";
        $params = ["nickname" => $input->nickname, "deviceId" => $input->deviceId];
        $res = $this->recordset->getJSONRecordSet($query, $params);
        return json_encode(array("status" => 200, "message" => "done"));
    }


    public function get_page()
    {
        return $this->page;
    }
}
?>
