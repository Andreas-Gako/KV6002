A word file shows the design of the arduino and the code that is used to create this system. 
The 2 pictures show that the code verifies and compiles with no errors.
The two folders contain the files nessesary to open the code in the Arduino IDE.
In order to run the arduino_complete the library:
Adafruit AM2320 sensor, Adafruit Unified Sensor,EspSoftwareSerial,ATtinySerialOut library will ned to be installed. 
This can be done by going to sketch - manage libraries- and the searching for the library name
